<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * CakePHP Shell
 * @author SOUISSI
 */
class scriptShell extends Shell {

    public $uses = array();
    public $tasks = array();

    function main() {
        $this->$this->redirect('http://192.168.42.156:3000');
    }

}
