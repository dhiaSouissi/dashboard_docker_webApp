/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author SOUISSI
 */
@Entity
@Table(name = "hosts")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Hosts.findAll", query = "SELECT h FROM Hosts h"),
    @NamedQuery(name = "Hosts.findByIdhosts", query = "SELECT h FROM Hosts h WHERE h.idhosts = :idhosts"),
    @NamedQuery(name = "Hosts.findByName", query = "SELECT h FROM Hosts h WHERE h.name = :name"),
    @NamedQuery(name = "Hosts.findByAddresseIP", query = "SELECT h FROM Hosts h WHERE h.addresseIP = :addresseIP"),
    @NamedQuery(name = "Hosts.findByPassword", query = "SELECT h FROM Hosts h WHERE h.password = :password")})
public class Hosts implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idhosts")
    private Integer idhosts;
    @Size(max = 45)
    @Column(name = "name")
    private String name;
    @Size(max = 45)
    @Column(name = "addresseIP")
    private String addresseIP;
    @Size(max = 45)
    @Column(name = "password")
    private String password;

    public Hosts() {
    }

    public Hosts(Integer idhosts) {
        this.idhosts = idhosts;
    }

    public Integer getIdhosts() {
        return idhosts;
    }

    public void setIdhosts(Integer idhosts) {
        this.idhosts = idhosts;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddresseIP() {
        return addresseIP;
    }

    public void setAddresseIP(String addresseIP) {
        this.addresseIP = addresseIP;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idhosts != null ? idhosts.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Hosts)) {
            return false;
        }
        Hosts other = (Hosts) object;
        if ((this.idhosts == null && other.idhosts != null) || (this.idhosts != null && !this.idhosts.equals(other.idhosts))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.Hosts[ idhosts=" + idhosts + " ]";
    }
    
}
